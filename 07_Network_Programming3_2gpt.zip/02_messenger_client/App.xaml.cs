﻿using System.Configuration;
using System.Data;
using System.Windows;
using _02_messenger_client;

namespace _02_messenger_client
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var login = new LoginWindow
            {
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ShowInTaskbar = false
            };

            bool? ok = login.ShowDialog();     // <-- діалогове вікно
            if (ok == true && !string.IsNullOrWhiteSpace(login.Nick))
            {
                var main = new MainWindow(login.Nick);
                MainWindow = main;             // (необов’язково, але корисно)
                main.Show();                   // <-- запускаємо головне вікно
            }
            else
            {
                Shutdown();                    // відміна/порожній нік — закриваємо застосунок
            }
        }
    }
}
