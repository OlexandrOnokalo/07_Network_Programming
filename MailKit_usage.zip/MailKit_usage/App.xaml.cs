using System.Windows;

namespace MailKit_usage
{
    public partial class App : Application
    {
    }
}