using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MailKit;
using MailKit.Net.Imap;
using MailKit.Search;
using MailKit.Security;
using MimeKit;

namespace MailKit_usage.Services
{
    public class ImapService : IAsyncDisposable
    {
        private readonly ImapClient _client = new();
        public ImapClient Client => _client;

        public async Task ConnectAsync(string email, string password, CancellationToken ct = default)
        {
            if (_client.IsConnected)
                await _client.DisconnectAsync(true, ct);

            await _client.ConnectAsync("imap.gmail.com", 993, SecureSocketOptions.SslOnConnect, ct);

            // Force simple auth (avoid XOAUTH2 prompt)
            _client.AuthenticationMechanisms.Remove("XOAUTH2");

            await _client.AuthenticateAsync(email, password, ct);
        }

        public async ValueTask DisposeAsync()
        {
            try
            {
                if (_client.IsConnected)
                    await _client.DisconnectAsync(true);
                _client.Dispose();
            }
            catch { /* ignore */ }
        }

        public async Task<IList<IMailFolder>> GetAllSelectableFoldersAsync(CancellationToken ct = default)
        {
            var result = new List<IMailFolder>();
            var personal = _client.PersonalNamespaces.Count > 0
                ? await _client.GetFolderAsync(_client.PersonalNamespaces[0], ct)
                : _client.GetFolder(_client.PersonalNamespaces[0]);

            async Task RecurseAsync(IMailFolder folder)
            {
                await folder.OpenAsync(FolderAccess.ReadOnly, ct);
                if (folder.Attributes.HasFlag(FolderAttributes.NoSelect) == false)
                    result.Add(folder);

                foreach (var sub in await folder.GetSubfoldersAsync(false, ct))
                {
                    await RecurseAsync(sub);
                }
            }

            // Add well-known Inbox first
            result.Add(_client.Inbox);

            // Recurse from top-level to capture others (Sent, Drafts, etc.)
            foreach (var top in await personal.GetSubfoldersAsync(false, ct))
                await RecurseAsync(top);

            // Distinct by FullName
            result = result.DistinctBy(f => f.FullName).ToList();

            // Ensure they are open for reading
            foreach (var f in result)
            {
                if (!f.IsOpen)
                    await f.OpenAsync(FolderAccess.ReadOnly, ct);
            }

            return result;
        }

        public static (int start, int end) GetPageRange(int totalCount, int pageIndex, int pageSize)
        {
            // pageIndex 0 => newest items
            var end = totalCount - (pageIndex * pageSize) - 1;
            var start = Math.Max(0, end - (pageSize - 1));
            if (end < 0) return (0, -1);
            return (start, end);
        }

        public async Task<IList<Models.EmailItem>> GetPageAsync(IMailFolder folder, int pageIndex, int pageSize, CancellationToken ct = default)
        {
            if (!folder.IsOpen)
                await folder.OpenAsync(FolderAccess.ReadOnly, ct);

            int total = folder.Count;
            var (start, end) = GetPageRange(total, pageIndex, pageSize);
            if (end < start) return new List<Models.EmailItem>();

            // Fetch summaries for the window
            var summaries = await folder.FetchAsync(start, end,
                MessageSummaryItems.UniqueId | MessageSummaryItems.Envelope | MessageSummaryItems.InternalDate, ct);

            // Newest last in this range; sort descending by index to show newest first
            var items = summaries
                .OrderByDescending(s => s.Index)
                .Select(s => new Models.EmailItem
                {
                    UniqueId = s.UniqueId,
                    From = s.Envelope.From?.ToString() ?? "",
                    Subject = s.Envelope.Subject ?? "",
                    Date = s.InternalDate ?? DateTimeOffset.MinValue
                })
                .ToList();

            return items;
        }

        public async Task<MimeMessage> GetMessageAsync(IMailFolder folder, UniqueId uid, CancellationToken ct = default)
        {
            if (!folder.IsOpen)
                await folder.OpenAsync(FolderAccess.ReadOnly, ct);
            return await folder.GetMessageAsync(uid, ct);
        }

        public async Task<bool> DeleteAsync(IMailFolder folder, UniqueId uid, CancellationToken ct = default)
        {
            await folder.OpenAsync(FolderAccess.ReadWrite, ct);
            await folder.AddFlagsAsync(uid, MessageFlags.Deleted, true, ct);
            await folder.ExpungeAsync(ct);
            await folder.CloseAsync(true, ct);
            // re-open readonly for further reads
            await folder.OpenAsync(FolderAccess.ReadOnly, ct);
            return true;
        }
    }
}