namespace MailKit_usage.Helpers
{
    public static class SessionState
    {
        public static string Email { get; set; } = string.Empty;
        public static string Password { get; set; } = string.Empty;
    }
}