using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace _02_ServerApp
{
    class Server
    {
        private readonly int _port = 4040;
        private readonly UdpClient _udp;
        private readonly HashSet<string> _members = new HashSet<string>(); // endpoint string "ip:port"

        public Server(int port = 4040)
        {
            _port = port;
            _udp = new UdpClient(_port);
        }

        public void Start()
        {
            Console.WriteLine($"[Server] Started on UDP {_port}.");
            Console.WriteLine("Waiting for clients...");

            var remote = new IPEndPoint(IPAddress.Any, 0);
            while (true)
            {
                byte[] buf;
                try
                {
                    buf = _udp.Receive(ref remote);
                }
                catch (SocketException se)
                {
                    Console.WriteLine($"[Server] Socket error: {se.Message}");
                    continue;
                }

                var msg = Encoding.UTF8.GetString(buf);
                var epKey = $"{remote.Address}:{remote.Port}";

                // Track members
                _members.Add(epKey);

                // Pretty-print what we received
                if (msg.StartsWith("$<join>|", StringComparison.OrdinalIgnoreCase))
                {
                    var nick = msg.Substring("$<join>|".Length).Trim();
                    if (string.IsNullOrWhiteSpace(nick)) nick = "Unknown";
                    Console.WriteLine($"[Server] Joined: {nick} (from {epKey})");
                    Broadcast($"[System] {nick} joined the chat.", remote);
                }
                else if (msg.StartsWith("$<leave>|", StringComparison.OrdinalIgnoreCase))
                {
                    var nick = msg.Substring("$<leave>|".Length).Trim();
                    Console.WriteLine($"[Server] Left: {nick} (from {epKey})");
                    Broadcast($"[System] {nick} left the chat.", remote);
                    _members.Remove(epKey);
                }
                else
                {
                    Console.WriteLine($"[Server] Message from {epKey}: {msg}");
                    Broadcast(msg, remote);
                }
            }
        }

        private void Broadcast(string message, IPEndPoint sender)
        {
            var data = Encoding.UTF8.GetBytes(message);
            foreach (var member in _members)
            {
                try
                {
                    var parts = member.Split(':');
                    var ip = IPAddress.Parse(parts[0]);
                    var port = int.Parse(parts[1]);
                    var ep = new IPEndPoint(ip, port);
                    _udp.Send(data, data.Length, ep);
                }
                catch
                {
                    // ignore
                }
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            var server = new Server(4040);
            server.Start();
        }
    }
}
