using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace _02_messenger_client
{
    public partial class MainWindow : Window
    {
        private readonly UdpClient _udp = new UdpClient(0); // random local port
        private IPEndPoint _serverEp = new IPEndPoint(IPAddress.Loopback, 4040);
        private string _nick = string.Empty;
        private bool _listening = false;

        public MainWindow()
        {
            InitializeComponent();

            var login = new LoginWindow();
            var ok = login.ShowDialog();
            if (ok != true)
            {
                Close();
                return;
            }
            _nick = login.Nickname.Trim();

            // Send JOIN
            SendRaw($"$<join>|{_nick}");

            // Start listener
            _listening = true;
            _ = Task.Run(ListenLoop);
        }

        private async Task ListenLoop()
        {
            while (_listening)
            {
                try
                {
                    var result = await _udp.ReceiveAsync();
                    var text = Encoding.UTF8.GetString(result.Buffer);
                    AppendMessage(text);
                }
                catch (ObjectDisposedException) { break; }
                catch (Exception ex)
                {
                    AppendMessage($"[Error] {ex.Message}");
                }
            }
        }

        private void AppendMessage(string text)
        {
            Dispatcher.Invoke(() =>
            {
                var tb = new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 6) };
                msgsPanel.Children.Add(tb);
            });
        }

        private void Send_Click(object sender, RoutedEventArgs e)
        {
            var msg = (txtMessage.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(msg))
            {
                MessageBox.Show("Message cannot be empty.", "Validation", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            SendRaw($"[{_nick}] {msg}");
            txtMessage.Clear();
        }

        private void SendRaw(string text)
        {
            var data = Encoding.UTF8.GetBytes(text);
            _udp.Send(data, data.Length, _serverEp);
        }

        protected override void OnClosed(EventArgs e)
        {
            try
            {
                SendRaw($"$<leave>|{_nick}");
                _listening = false;
                _udp.Close();
            }
            catch { }
            base.OnClosed(e);
        }
    }
}
