using System.Windows;

namespace _02_messenger_client
{
    public partial class App : Application
    {
    }
}
