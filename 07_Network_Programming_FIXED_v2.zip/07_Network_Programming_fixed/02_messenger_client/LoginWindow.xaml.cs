using System.Windows;

namespace _02_messenger_client
{
    public partial class LoginWindow : Window
    {
        public string Nickname { get; private set; } = string.Empty;

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            var nick = (txtNick.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(nick))
            {
                MessageBox.Show("Nickname cannot be empty.", "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            Nickname = nick;
            DialogResult = true;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
